package org.tcs.controller;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reg")
public class CustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final String DB_URL = "jdbc:mysql://localhost:3306/team17";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "root";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String customerId = request.getParameter("customerId");
        String title = request.getParameter("title");
        String customerName = request.getParameter("customerName");
        String dobStr = request.getParameter("dateOfBirth");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("mobileNumber");
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        try {
            // Debug: Checking received parameters
            System.out.println("Received Data: " + customerId + ", " + customerName + ", " + email);

            // Validate password match
            if (!password.equals(confirmPassword)) {
                request.setAttribute("errorMessage", "Password mismatch");
                request.getRequestDispatcher("registration.jsp").include(request, response);
                return;
            }

            // Validate age
            LocalDate dob = LocalDate.parse(dobStr, DateTimeFormatter.ISO_DATE);
            LocalDate today = LocalDate.now();
            int age = Period.between(dob, today).getYears();

            if (age < 18) {
                request.setAttribute("errorMessage", "Age is less than 18");
                request.getRequestDispatcher("registration.jsp").include(request, response);
                return;
            }

            // Database Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                System.out.println("Database connected successfully.");

                // Check if customerId exists in DB
                String checkQuery = "SELECT * FROM CustomerDatabase WHERE CustomerId = ?";
                PreparedStatement checkPs = conn.prepareStatement(checkQuery);
                checkPs.setString(1, customerId);
                ResultSet rs = checkPs.executeQuery();

                if (!rs.next()) {
                    // If customerId not found
                    request.setAttribute("errorMessage", "Customer ID does not exist. Please contact support.");
                    request.getRequestDispatcher("registration.jsp").include(request, response);
                    return;
                }
                
               
              
                try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    System.out.println("Database connected successfully.");

                    // Check if customerId exists in DB
                    String check1 = "SELECT * FROM Customer WHERE CustomerId = ?";
                    PreparedStatement check2 = conn.prepareStatement(check1);
                    check2.setString(1, customerId);
                    ResultSet rs1 = check2.executeQuery();

                    if (rs.next()) {
                        // If customerId not found
                        request.setAttribute("errorMessage", "Customer ID Already Exists Plz Login.");
                        request.getRequestDispatcher("registration.jsp").include(request, response);
                        return;
                      
                    }
                    
                // Insert customer data into the database
                String insertQuery = "INSERT INTO Customer(CustomerId, title, customerName, dateOfBirth, email, mobileNumber, userId, password,confirmpassword) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
                PreparedStatement insertPs = conn.prepareStatement(insertQuery);
                insertPs.setString(1, customerId);
                insertPs.setString(2, title);
                insertPs.setString(3, customerName);
                insertPs.setDate(4, Date.valueOf(dob));
                insertPs.setString(5, email);
                insertPs.setString(6, mobileNumber);
                insertPs.setString(7, userId);
                insertPs.setString(8, password);
                insertPs.setString(9, confirmPassword);

                int rowsAffected = insertPs.executeUpdate();
                System.out.println("Rows affected: " + rowsAffected);
                System.out.println("done..........");

                if (rowsAffected > 0) {
                    response.sendRedirect("login.jsp?message=Registration successful! Please login.");
                } else {
                    request.setAttribute("errorMessage", "Registration failed. Please try again.");
                    request.getRequestDispatcher("registration.jsp").include(request, response);
                }
            } catch (SQLException e) {
                // Handling SQL exceptions with user-friendly message
                e.printStackTrace();
                request.setAttribute("errorMessage", "Enter valid details.");
                request.getRequestDispatcher("registration.jsp").include(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred. Please try again.");
            request.getRequestDispatcher("registration.jsp").include(request, response);
        }
        } catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}finally {
        	        }
    
    }
    }
    

