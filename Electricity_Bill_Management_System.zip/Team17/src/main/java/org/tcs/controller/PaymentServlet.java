package org.tcs.controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String selectedBills = req.getParameter("selectedBills");
        String totalAmountStr = req.getParameter("totalAmount");

        if (selectedBills == null || totalAmountStr == null) {
            out.println("<h3>Error: Invalid payment request.</h3>");
            return;
        }

        double totalAmount = 0;
        try {
            totalAmount = Double.parseDouble(totalAmountStr);
        } catch (NumberFormatException e) {
            out.println("<h3>Error: Invalid total amount format.</h3>");
            return;
        }

        if (totalAmount <= 0) {
            out.println("<h3>Error: Total amount must be greater than zero.</h3>");
            return;
        }

        // Database connection details
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        String dbUrl = "jdbc:mysql://localhost:3306/team17";
        String dbUser = "root";
        String dbPassword = "root";

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String[] billIds = selectedBills.split(",");
            conn.setAutoCommit(false); // Transaction management

            String deleteQuery = "DELETE FROM Bill WHERE billId = ?";
            try (PreparedStatement ps = conn.prepareStatement(deleteQuery)) {
                for (String billId : billIds) {
                    ps.setLong(1, Long.parseLong(billId.trim()));
                    ps.executeUpdate();
                }
                conn.commit(); // Commit transaction if all deletes succeed
            } catch (Exception e) {
                conn.rollback(); // Rollback on error
                out.println("<h3>Error: Payment failed. Transaction rolled back.</h3>");
                e.printStackTrace();
                return;
            }

            // Save total amount in session to show on next page (optional)
            HttpSession session = req.getSession();
            session.setAttribute("paidAmount", totalAmount);

            // Redirect to credit card payment page after deletion
            resp.sendRedirect("creditcardpayment.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3>Error: Payment failed - " + e.getMessage() + "</h3>");
        }
    }
}
