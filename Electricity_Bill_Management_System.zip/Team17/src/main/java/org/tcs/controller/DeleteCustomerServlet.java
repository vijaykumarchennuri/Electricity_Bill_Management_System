package org.tcs.controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DeleteCustomerServlet")
public class DeleteCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final String DB_URL = "jdbc:mysql://localhost:3306/team17";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "root";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Long customerId = (Long) session.getAttribute("customerId");

        if (customerId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "DELETE FROM Customer WHERE customerId = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setLong(1, customerId);
                ps.executeUpdate();
            }

            // Clear session and redirect to login
            session.invalidate();
            response.sendRedirect("login.jsp?message=Account deleted successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("customerDetails.jsp?error=Delete failed.");
        }
    }
}
