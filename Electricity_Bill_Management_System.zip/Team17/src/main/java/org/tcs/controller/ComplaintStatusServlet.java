package org.tcs.controller;

import org.tcs.bean.Complaint;
import org.tcs.dao.ComplaintStatusDAO;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/ComplaintStatusServlet")
public class ComplaintStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String complaintId = req.getParameter("complaintId");
        Complaint complaint = ComplaintStatusDAO.getComplaintById(complaintId);

        resp.setContentType("text/html");
        resp.getWriter().println("<!DOCTYPE html>");
        resp.getWriter().println("<html><head><title>Complaint Status</title>");
        resp.getWriter().println("<style>");
        resp.getWriter().println("body { font-family: Arial, sans-serif; background-color: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }");
        resp.getWriter().println(".status-container { background-color: #ffffff; padding: 20px 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15); text-align: left; max-width: 500px; width: 90%; }");
        resp.getWriter().println("h2 { color: #2c3e50; }");
        resp.getWriter().println("p { font-size: 1rem; margin: 5px 0; color: #34495e; }");
        resp.getWriter().println("</style></head><body>");
        resp.getWriter().println("<div class='status-container'>");

        if (complaint != null) {
            resp.getWriter().println("<h2>Complaint Details</h2>");
            resp.getWriter().println("<p><b>Complaint ID:</b> " + complaint.getComplaintId() + "</p>");
            resp.getWriter().println("<p><b>Complaint Type:</b> " + complaint.getComplaintType() + "</p>");
            resp.getWriter().println("<p><b>Category:</b> " + complaint.getCategory() + "</p>");
            resp.getWriter().println("<p><b>Landmark:</b> " + complaint.getLandMark() + "</p>");
            resp.getWriter().println("<p><b>Customer Name:</b> " + complaint.getCustomerName() + "</p>");
            resp.getWriter().println("<p><b>Problem:</b> " + complaint.getProblem() + "</p>");
            resp.getWriter().println("<p><b>Status:</b> " + complaint.getStatus() + "</p>");
            resp.getWriter().println("<p><b>Status Update Date:</b> " + (complaint.getStatusUpdateDate() != null ? complaint.getStatusUpdateDate() : "N/A") + "</p>");
        } else {
            resp.getWriter().println("<h2>No Complaint Found</h2>");
            resp.getWriter().println("<p>The complaint ID you entered does not exist.</p>");
        }

        resp.getWriter().println("<a href='complaintStatus.jsp'>Check Another Complaint</a>");
        resp.getWriter().println("</div></body></html>");
    }
}
