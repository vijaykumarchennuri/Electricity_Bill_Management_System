package org.tcs.controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/DownloadReceiptServlet")
public class DownloadReceiptServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String paidAmount = req.getParameter("paidAmount");
        String selectedBills = req.getParameter("selectedBills");

        resp.setContentType("text/plain");
        // The header tells the browser to download the file with this filename
        resp.setHeader("Content-Disposition", "attachment;filename=PaymentReceipt.txt");

        PrintWriter out = resp.getWriter();
        out.println("***** Payment Receipt *****");
        out.println("Paid Amount: ₹" + paidAmount);
        out.println("Bills Paid (IDs): " + selectedBills);
        out.println();
        out.println("Thank you for your payment!");
        out.close();
    }
}
