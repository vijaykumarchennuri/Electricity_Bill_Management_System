package org.tcs.controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UpdateCustomerServlet")
public class UpdateCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String customerName = request.getParameter("customerName");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("mobileNumber");

        HttpSession session = request.getSession();
        Long customerId = (Long) session.getAttribute("customerId");

        if (customerId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/team17", "root", "root");

            String query = "UPDATE Customer SET customerName = ?, email = ?, mobileNumber = ? WHERE customerId = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, customerName);
            ps.setString(2, email);
            ps.setString(3, mobileNumber);
            ps.setLong(4, customerId);

            int rowsUpdated = ps.executeUpdate();
            conn.close();

            if (rowsUpdated > 0) {
                response.sendRedirect("customerDetails.jsp?updateSuccess=true");
            } else {
                response.sendRedirect("customerDetails.jsp?updateError=true");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("customerDetails.jsp?updateError=true");
        }
    }
}
