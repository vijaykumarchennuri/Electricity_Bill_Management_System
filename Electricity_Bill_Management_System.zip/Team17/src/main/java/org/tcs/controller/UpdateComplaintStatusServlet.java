package org.tcs.controller;

import org.tcs.dao.ComplaintDAO;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/UpdateComplaintStatusServlet")

public class UpdateComplaintStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String complaintId = req.getParameter("complaintId");
        String status = req.getParameter("status");

        boolean updated = ComplaintDAO.updateComplaintStatus(complaintId, status);

        resp.setContentType("text/html");
//        if (updated) {
//            resp.getWriter().println("<h3>Status updated successfully!</h3>");
//        } else {
//            resp.getWriter().println("<h3>Failed to update status.</h3>");
//        }
//        resp.getWriter().println("<a href='ComplaintAdmin.jsp'>Back to Complaints</a>");
        
        resp.setContentType("text/html");
        resp.getWriter().println("<!DOCTYPE html>");
        resp.getWriter().println("<html><head><title>Status Update</title>");
        resp.getWriter().println("<style>");
        resp.getWriter().println("body { font-family: Arial, sans-serif; background-color: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }");
        resp.getWriter().println(".message-container { background-color: #ffffff; padding: 20px 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15); text-align: center; max-width: 400px; width: 90%; }");
        resp.getWriter().println(".message-container h3 { font-size: 1.4rem; margin-bottom: 15px; color: " + (updated ? "#27ae60" : "#e74c3c") + "; }"); // Green for success, Red for failure
        resp.getWriter().println(".message-container p { font-size: 1rem; margin-bottom: 10px; color: #34495e; }");
        resp.getWriter().println(".message-container a { display: inline-block; text-decoration: none; background-color: #3498db; color: #ffffff; padding: 8px 15px; border-radius: 6px; transition: background 0.3s; font-size: 0.95rem; }");
        resp.getWriter().println(".message-container a:hover { background-color: #2980b9; }");
        resp.getWriter().println("</style></head>");
        resp.getWriter().println("<body><div class='message-container'>");

        // Conditional Message
        if (updated) {
            resp.getWriter().println("<h3>Status updated successfully!</h3>");
        } else {
            resp.getWriter().println("<h3>Failed to update status.</h3>");
        }

        resp.getWriter().println("<a href='complaintAdmin.jsp'>Back to Complaints</a>");
        resp.getWriter().println("</div></body></html>");

    }
    
    
}
