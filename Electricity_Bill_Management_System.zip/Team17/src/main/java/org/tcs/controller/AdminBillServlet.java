package org.tcs.controller;

import org.tcs.dao.BillDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/AdminBillServlet")
public class AdminBillServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String customerIdStr = req.getParameter("customerId");
        String duePaymentStr = req.getParameter("duePayment");
        String month = req.getParameter("month");
        String payableAmountStr = req.getParameter("payableAmount");

        resp.setContentType("text/html");

        try {
            long customerId = Long.parseLong(customerIdStr);
            double duePayment = Double.parseDouble(duePaymentStr);
            double payableAmount = Double.parseDouble(payableAmountStr);

            boolean isAdded = BillDAO.addBill(customerId, duePayment, month, payableAmount);

//            if (isAdded) {
//                resp.getWriter().println("<h3 style='color:green;'>Bill Added Successfully!</h3>");
//            } else {
//                resp.getWriter().println("<h3 style='color:red;'>Failed to Add Bill. Please try again.</h3>");
//            }
            
            
            resp.getWriter().println("<style>"
            	    + "body, html {"
            	    + "  height: 100%;"
            	    + "  margin: 0;"
            	    + "  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;"
            	    + "  background-color: #f9f9f9;"
            	    + "  display: flex;"
            	    + "  justify-content: center;"
            	    + "  align-items: center;"
            	    + "}"
            	    + ".container {"
            	    + "  background: white;"
            	    + "  padding: 30px 50px;"
            	    + "  border-radius: 12px;"
            	    + "  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);"
            	    + "  text-align: center;"
            	    + "  max-width: 400px;"
            	    + "  width: 90%;"
            	    + "}"
            	    + ".success {"
            	    + "  color: #2e7d32;"
            	    + "  font-weight: 700;"
            	    + "  font-size: 22px;"
            	    + "  margin-bottom: 20px;"
            	    + "}"
            	    + ".error {"
            	    + "  color: #c62828;"
            	    + "  font-weight: 700;"
            	    + "  font-size: 22px;"
            	    + "  margin-bottom: 20px;"
            	    + "}"
            	    + ".back-button {"
            	    + "  display: inline-block;"
            	    + "  background-color: #1976d2;"
            	    + "  color: white;"
            	    + "  padding: 12px 30px;"
            	    + "  border-radius: 8px;"
            	    + "  text-decoration: none;"
            	    + "  font-weight: 600;"
            	    + "  font-size: 16px;"
            	    + "  transition: background-color 0.3s ease;"
            	    + "}"
            	    + ".back-button:hover {"
            	    + "  background-color: #115293;"
            	    + "}"
            	    + "</style>");

            	if (isAdded) {
            	    resp.getWriter().println(
            	        "<div class='container'>" +
            	        "<div class='success'> Bill Added Successfully!</div>" + "<br>"+
            	        "<a href='login.jsp' class='back-button'>Back to Login</a>" +
            	        "</div>"
            	    );
            	} else {
            	    resp.getWriter().println(
            	        "<div class='container'>" +
            	        "<div class='error'> Failed to Add Bill. Please try again.</div>" +
            	        "<a href='login.jsp' class='back-button'>Back to Login</a>" +
            	        "</div>"
            	    );
            	}



        } catch (NumberFormatException e) {
            resp.getWriter().println("<h3 style='color:red;'>Invalid input. Please enter valid numbers for Customer ID and amounts.</h3>");
        }

        resp.getWriter().println("<a href='adminBill.jsp'>Back to Admin Page</a>");
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("adminBill.jsp");
    }
}
