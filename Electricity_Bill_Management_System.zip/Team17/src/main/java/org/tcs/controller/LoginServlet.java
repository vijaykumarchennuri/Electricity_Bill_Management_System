package org.tcs.controller;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final String DB_URL = "jdbc:mysql://localhost:3306/team17";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "root";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("userEmailOrId"); // email or userId or admin username
        String password = request.getParameter("password");

        // Check if admin
        if ("admin".equals(username) && "1234".equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("admin", "Admin");  // set admin flag or role
            response.sendRedirect("admin.jsp");
            return;
        }

        // If not admin, check customer login
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {

                String query = "SELECT customerId, customerName, userId, email FROM Customer WHERE (userId = ? OR email = ?) AND password = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, username);
                ps.setString(2, username);
                ps.setString(3, password);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    long customerId = rs.getLong("customerId");
                    String customerName = rs.getString("customerName");

                    HttpSession session = request.getSession();
                    session.setAttribute("user", customerName);         // For welcome message
                    session.setAttribute("customerId", customerId);     // For fetching bills
                    response.sendRedirect("home.jsp");
                } else {
                    // Invalid login
                    request.setAttribute("errorMessage", "Invalid username or password");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
