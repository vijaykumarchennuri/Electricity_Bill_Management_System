package org.tcs.controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/PaymentProcessingServlet")
public class PaymentProcessingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String[] selectedBills = req.getParameter("selectedBills").split(",");

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/team17", "root", "root")) {
            String deleteQuery = "DELETE FROM Bill WHERE billId = ?";
            PreparedStatement ps = conn.prepareStatement(deleteQuery);

            for (String billId : selectedBills) {
                ps.setLong(1, Long.parseLong(billId));
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        resp.sendRedirect("paymentSuccess.jsp");
    }
}
