package org.tcs.bean;

public class Customer {
	    private long customerId;
	    private String title;
	    private String customerName;
	    private String dateOfBirth;
	    private String email;
	    private long mobileNumber;
	    private String userId;
	    private String password;
	    private String confirmPassword;

	    // Getters and Setters
	    public long getCustomerId() { return customerId; }
	    public void setCustomerId(long customerId) { this.customerId = customerId; }

	    public String getTitle() { return title; }
	    public void setTitle(String title) { this.title = title; }

	    public String getCustomerName() { return customerName; }
	    public void setCustomerName(String customerName) { this.customerName = customerName; }

	    public String getDateOfBirth() { return dateOfBirth; }
	    public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }

	    public String getEmail() { return email; }
	    public void setEmail(String email) { this.email = email; }

	    public long getMobileNumber() { return mobileNumber; }
	    public void setMobileNumber(long mobileNumber) { this.mobileNumber = mobileNumber; }

	    public String getUserId() { return userId; }
	    public void setUserId(String userId) { this.userId = userId; }

	    public String getPassword() { return password; }
	    public void setPassword(String password) { this.password = password; }

	    public String getConfirmPassword() { return confirmPassword; }
	    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }
	}

