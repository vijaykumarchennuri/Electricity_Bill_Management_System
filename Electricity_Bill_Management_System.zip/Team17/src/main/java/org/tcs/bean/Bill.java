package org.tcs.bean;

public class Bill {
    private int billId;
    private long customerId;
    private String month;
    private double duePayment;
    private double payableAmount;
    private String status;

    public int getBillId() {
        return billId;
    }
    public void setBillId(int billId) {
        this.billId = billId;
    }
    public long getCustomerId() {
        return customerId;
    }
    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }
    public String getMonth() {
        return month;
    }
    public void setMonth(String month) {
        this.month = month;
    }
    public double getDuePayment() {
        return duePayment;
    }
    public void setDuePayment(double duePayment) {
        this.duePayment = duePayment;
    }
    public double getPayableAmount() {
        return payableAmount;
    }
    public void setPayableAmount(double payableAmount) {
        this.payableAmount = payableAmount;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}
