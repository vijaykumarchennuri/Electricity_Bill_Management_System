package org.tcs.bean;

import java.sql.Timestamp;

public class Complaint {
    private String complaintId;   // random generated ID
    private String complaintType;
    private String category;
    private String landMark;
    private String customerName;
    private String problem;
    private long customerid;
    private String address;
    private long mobileNumber;
    private String status;       // Pending or Resolved
    private Timestamp statusUpdateDate;
	public String getComplaintId() {
		return complaintId;
	}
	
	public Complaint() {
		
	}

	public Complaint(String complaintId, String complaintType, String category, String landMark, String customerName,
			String problem, long customerid, String address, long mobileNumber, String status,
			Timestamp statusUpdateDate) {
		super();
		this.complaintId = complaintId;
		this.complaintType = complaintType;
		this.category = category;
		this.landMark = landMark;
		this.customerName = customerName;
		this.problem = problem;
		this.customerid = customerid;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.status = status;
		this.statusUpdateDate = statusUpdateDate;
	}

	public String getComplaintType() {
		return complaintType;
	}

	public void setComplaintType(String complaintType) {
		this.complaintType = complaintType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getStatusUpdateDate() {
		return statusUpdateDate;
	}

	public void setStatusUpdateDate(Timestamp statusUpdateDate) {
		this.statusUpdateDate = statusUpdateDate;
	}

	public void setComplaintId(String complaintId) {
		this.complaintId = complaintId;
	}
	
}