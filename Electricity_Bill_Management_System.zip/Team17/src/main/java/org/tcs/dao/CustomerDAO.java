package org.tcs.dao;

import java.sql.*;

import org.tcs.bean.Customer;
public class CustomerDAO {
    private Connection connection;

    public CustomerDAO() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/team17?user=root&password=root");
    }

    public boolean registerCustomer(Customer customer) throws SQLException {
        String query = "INSERT INTO Customer VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setLong(1, customer.getCustomerId());
            pstmt.setString(2, customer.getTitle());
            pstmt.setString(3, customer.getCustomerName());
            pstmt.setString(4, customer.getDateOfBirth());
            pstmt.setString(5, customer.getEmail());
            pstmt.setLong(6, customer.getMobileNumber());
            pstmt.setString(7, customer.getUserId());
            pstmt.setString(8, customer.getPassword());
            pstmt.setString(9, customer.getConfirmPassword());
            return pstmt.executeUpdate() > 0;
        }
    }
}

