package org.tcs.dao;

import org.tcs.bean.Complaint;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ComplaintDAO {

    private static final String dbURL = "jdbc:mysql://localhost:3306/team17?";
    private static final String dbUser = "root";  // replace with your username
    private static final String dbPass = "root";  // replace with your password

    static {
        try {
        	 Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/team17?user=root&password=root");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbURL, dbUser, dbPass);
    }

    public static boolean saveComplaint(Complaint c) {
        boolean flag = false;
        String sql = "INSERT INTO Complaint(complaintId, complaintType, category, landMark, customerName, problem, customerid, address, mobileNumber, Status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getComplaintId());
            ps.setString(2, c.getComplaintType());
            ps.setString(3, c.getCategory());
            ps.setString(4, c.getLandMark());
            ps.setString(5, c.getCustomerName());
            ps.setString(6, c.getProblem());
            ps.setLong(7, c.getCustomerid());
            ps.setString(8, c.getAddress());
            ps.setLong(9, c.getMobileNumber());
            ps.setString(10, "Pending");  // default status
            int rows = ps.executeUpdate();
            flag = (rows > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public static List<Complaint> getAllComplaints() {
        List<Complaint> list = new ArrayList<>();
        String sql = "SELECT * FROM Complaint";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Complaint c = new Complaint();
                c.setComplaintId(rs.getString("complaintId"));
                c.setComplaintType(rs.getString("complaintType"));
                c.setCategory(rs.getString("category"));
                c.setLandMark(rs.getString("landMark"));
                c.setCustomerName(rs.getString("customerName"));
                c.setProblem(rs.getString("problem"));
                c.setCustomerid(rs.getLong("customerid"));
                c.setAddress(rs.getString("address"));
                c.setMobileNumber(rs.getLong("mobileNumber"));
                c.setStatus(rs.getString("Status"));
                c.setStatusUpdateDate(rs.getTimestamp("statusUpdateDate"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static boolean updateComplaintStatus(String complaintId, String status) {
        boolean flag = false;
        String sql = "UPDATE Complaint SET Status = ?, statusUpdateDate = ? WHERE complaintId = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            if ("Resolved".equalsIgnoreCase(status)) {
                ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            } else {
                ps.setTimestamp(2, null);
            }
            ps.setString(3, complaintId);
            int rows = ps.executeUpdate();
            flag = (rows > 0);

            if (flag && "Resolved".equalsIgnoreCase(status)) {
                updateCustomerStatusByComplaint(complaintId, "Resolved", con);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    private static void updateCustomerStatusByComplaint(String complaintId, String status, Connection con) throws SQLException {
        String getCustSql = "SELECT customerid FROM Complaint WHERE complaintId = ?";
        try (PreparedStatement ps1 = con.prepareStatement(getCustSql)) {
            ps1.setString(1, complaintId);
            ResultSet rs = ps1.executeQuery();
            if (rs.next()) {
                long custId = rs.getLong("customerid");
                String updateCustSql = "UPDATE customer SET complaintStatus = ? WHERE customerid = ?";
                try (PreparedStatement ps2 = con.prepareStatement(updateCustSql)) {
                    ps2.setString(1, status);
                    ps2.setLong(2, custId);
                    ps2.executeUpdate();
                }
            }
        }
    }
}
