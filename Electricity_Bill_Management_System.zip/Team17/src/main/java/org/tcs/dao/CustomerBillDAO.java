package org.tcs.dao;

import org.tcs.bean.Bill;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerBillDAO {

    // Existing addBill method...

	public static List<Bill> getBillsByCustomerId(String customerId) {
	    List<Bill> bills = new ArrayList<>();
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        try (Connection con = DriverManager.getConnection(
	                "jdbc:mysql://localhost:3306/team17?useSSL=false&allowPublicKeyRetrieval=true", "root", "root")) {

	            String sql = "SELECT * FROM Bill_Table WHERE customerId = ? AND status = 'Due'";
	            PreparedStatement ps = con.prepareStatement(sql);
	            ps.setString(1, customerId);

	            ResultSet rs = ps.executeQuery();

	            while (rs.next()) {
	                Bill bill = new Bill();
	                bill.setBillId(rs.getInt("billId"));
	                bill.setCustomerId(rs.getLong("customerId"));
	                bill.setDuePayment(rs.getDouble("duePayment"));
	                bill.setMonth(rs.getString("month"));
	                bill.setPayableAmount(rs.getDouble("payableAmount"));
	                bill.setStatus(rs.getString("status"));
	                bills.add(bill);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return bills;
	}
}