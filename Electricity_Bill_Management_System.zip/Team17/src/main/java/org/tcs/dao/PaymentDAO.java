package org.tcs.dao;

import java.sql.*;

public class PaymentDAO {
    public static boolean processPayment(String customerId, double amount) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/team17?user=root&password=root");

            String sql = "UPDATE Bill SET status = 'Paid' WHERE customerId = ? AND payableAmount = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, customerId);
            ps.setDouble(2, amount);

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}