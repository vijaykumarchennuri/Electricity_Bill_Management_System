package org.tcs.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.tcs.bean.Bill;

public class BillDAO {

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load driver once
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static final String URL = "jdbc:mysql://localhost:3306/team17?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "root";

    public static boolean addBill(long customerId, double duePayment, String month, double payableAmount) {
    	   String sql = "INSERT INTO bill (customerId, duePayment, month, payableAmount, status) VALUES (?, ?, ?, ?, ?)";
    	   try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
    	        PreparedStatement ps = conn.prepareStatement(sql)) {
    	        
    	       conn.setAutoCommit(true); // Auto-commit enabled
    	       
    	       ps.setLong(1, customerId);
    	       ps.setDouble(2, duePayment);
    	       ps.setString(3, month);
    	       ps.setDouble(4, payableAmount);
    	       ps.setString(5, "Pending");

    	       int rows = ps.executeUpdate();
    	       return rows > 0;

    	   } catch (SQLException e) {
    	       e.printStackTrace();
    	       return false;
    	   }
    }

    public List<Bill> getBillsByCustomerId(long customerId) {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT billId, customerId, month, duePayment, payableAmount, status FROM bill WHERE customerId = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Bill bill = new Bill();
                    bill.setBillId(rs.getInt("billId"));
                    bill.setCustomerId(rs.getLong("customerId"));
                    bill.setMonth(rs.getString("month"));
                    bill.setDuePayment(rs.getDouble("duePayment"));
                    bill.setPayableAmount(rs.getDouble("payableAmount"));
                    bill.setStatus(rs.getString("status"));
                    bills.add(bill);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bills;
    }
}
