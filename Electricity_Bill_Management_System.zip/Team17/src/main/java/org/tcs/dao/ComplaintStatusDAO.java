package org.tcs.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.tcs.bean.Complaint;

public class ComplaintStatusDAO {
    
    public static Complaint getComplaintById(String complaintId) {
        Complaint complaint = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Database Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/team17", "root", "root");
            String sql = "SELECT * FROM Complaint WHERE complaintId = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, complaintId);
            rs = ps.executeQuery();
            
            // Check if complaint exists
            if (rs.next()) {
                complaint = new Complaint();
                complaint.setComplaintId(rs.getString("complaintId"));
                complaint.setComplaintType(rs.getString("complaintType"));
                complaint.setCategory(rs.getString("category"));
                complaint.setLandMark(rs.getString("landMark"));
                complaint.setCustomerName(rs.getString("customerName"));
                complaint.setProblem(rs.getString("problem"));
                complaint.setStatus(rs.getString("Status"));
                complaint.setStatusUpdateDate(rs.getTimestamp("statusUpdateDate"));
            }
        } catch (Exception e) {
            System.out.println("Database Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        return complaint;
    }
}
